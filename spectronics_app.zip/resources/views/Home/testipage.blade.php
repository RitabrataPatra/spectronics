@include('Home.header')
<!-- ============================
    Slider
============================== -->


<!-- ========================= 
  Testimonials layout 2
  =========================  -->
@include('Home.testimonial')
<!-- ========================
  Footer
========================== -->
@include('Home.footer')