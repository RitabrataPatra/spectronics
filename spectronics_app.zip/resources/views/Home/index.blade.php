    @include('Home.header')
    <!-- ============================
        Slider
    ============================== -->
    @include('Home.body')
    <!-- ======================
     Work Process 
    ========================= -->
    @include('Home.product')

    <!-- ========================= 
      Testimonials layout 2
      =========================  -->
    @include('Home.testimonial')
    <!-- ========================
      Footer
    ========================== -->
    @include('Home.footer')